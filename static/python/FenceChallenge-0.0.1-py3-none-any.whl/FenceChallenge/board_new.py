import numpy as np
import cv2
from .pentominos import *
from .pentomino_cv import *

BOARD_GRID = 20
BOARD_SIZE = 500

def GetPentominosDebug(textInt = -1, textString = None):
    if textInt == -1 and textString is None:
        return '([[1, 7, 10, 2, 12, 6, 9, 5, 4, 11, 8, 3], [[17, 9], [15, 6], [12, 6], [8, 6], [5, 8], [3, 10], [4, 13], [4, 16], [7, 17], [12, 17], [16, 17], [17, 13]], [4, 6, 6, 5, 4, 7, 7, 7, 1, 7, 1, 4]], [107], [[[6, 6], [6, 7], [6, 8], [6, 9], [6, 10], [6, 12], [6, 14], [7, 5], [7, 6], [7, 7], [7, 8], [7, 9], [7, 10], [7, 11], [7, 12], [7, 13], [7, 14], [8, 5], [8, 6], [8, 7], [8, 8], [8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14], [8, 15], [9, 3], [9, 4], [9, 5], [9, 6], [9, 7], [9, 8], [9, 9], [9, 10], [9, 11], [9, 12], [9, 13], [9, 14], [9, 15], [10, 3], [10, 4], [10, 5], [10, 6], [10, 7], [10, 8], [10, 9], [10, 10], [10, 11], [10, 12], [10, 13], [10, 14], [10, 15], [11, 3], [11, 4], [11, 5], [11, 6], [11, 7], [11, 8], [11, 9], [11, 10], [11, 11], [11, 12], [11, 13], [11, 14], [11, 15], [12, 4], [12, 5], [12, 6], [12, 7], [12, 8], [12, 9], [12, 10], [12, 11], [12, 12], [12, 13], [12, 14], [12, 15], [13, 5], [13, 6], [13, 7], [13, 8], [13, 9], [13, 10], [13, 11], [13, 12], [13, 13], [13, 14], [14, 5], [14, 6], [14, 7], [14, 8], [14, 9], [14, 10], [14, 11], [14, 12], [14, 13], [14, 14], [15, 7], [15, 8], [15, 9], [15, 10], [15, 11], [15, 12], [15, 13], [15, 14]]])'
    elif textInt == 0 or textString == 'long':
        return '([[1, 7, 10, 2, 12, 6, 9, 5, 4, 11, 8, 3], [[17, 9], [15, 6], [12, 6], [8, 6], [5, 8], [3, 10], [4, 13], [4, 16], [7, 17], [12, 17], [16, 17], [17, 13]], [4, 6, 6, 5, 4, 7, 7, 7, 1, 7, 1, 4]], [107], [[[6, 6], [6, 7], [6, 8], [6, 9], [6, 10], [6, 12], [6, 14], [7, 5], [7, 6], [7, 7], [7, 8], [7, 9], [7, 10], [7, 11], [7, 12], [7, 13], [7, 14], [8, 5], [8, 6], [8, 7], [8, 8], [8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14], [8, 15], [9, 3], [9, 4], [9, 5], [9, 6], [9, 7], [9, 8], [9, 9], [9, 10], [9, 11], [9, 12], [9, 13], [9, 14], [9, 15], [10, 3], [10, 4], [10, 5], [10, 6], [10, 7], [10, 8], [10, 9], [10, 10], [10, 11], [10, 12], [10, 13], [10, 14], [10, 15], [11, 3], [11, 4], [11, 5], [11, 6], [11, 7], [11, 8], [11, 9], [11, 10], [11, 11], [11, 12], [11, 13], [11, 14], [11, 15], [12, 4], [12, 5], [12, 6], [12, 7], [12, 8], [12, 9], [12, 10], [12, 11], [12, 12], [12, 13], [12, 14], [12, 15], [13, 5], [13, 6], [13, 7], [13, 8], [13, 9], [13, 10], [13, 11], [13, 12], [13, 13], [13, 14], [14, 5], [14, 6], [14, 7], [14, 8], [14, 9], [14, 10], [14, 11], [14, 12], [14, 13], [14, 14], [15, 7], [15, 8], [15, 9], [15, 10], [15, 11], [15, 12], [15, 13], [15, 14]]])'
    elif textInt == 1 or textString == 'short':
        return '([[3, 8, 5], [[8, 11], [6, 14], [9, 13]], [1, 7, 6]], [4], [[[11, 6], [11, 7], [12, 6], [12, 7]]])'
    elif textInt == 2 or textString == 'empty':
        return 'No result! Check if the corners are in the frame and the pentominos are placed within the grid!'
    elif textInt == 3 or textString == 'noArea':
        return 'No fenced areas! Check the pentomino placements!'
    elif textInt == 4 or textString == 'duplicate':
        return 'Duplicate pentominos! Only use one of each shape!'
    
def GetAreaInfo(pentominoIDs, boardCoords, rotations, flip):
    if (pentominoIDs is None or boardCoords is None or rotations is None or flip is None):
        return 'No pentominos on the board!'
    if (len(pentominoIDs) == 0 or len(boardCoords) == 0 or len(rotations) == 0 or len(flip) == 0):
        return 'No pentominos on the board!'
    for i in range(len(boardCoords)):
        boardCoords[i][1] = 20-boardCoords[i][1]
        boardCoords[i][0] += 1
    orientations = []
    for i in range(len(rotations)):
        if flip[i] == 0:
            orientations.append(rotations[i])
        else:
            orientations.append(4 + rotations[i])
    area, sorted_list, fenced_areas = GetArea(ids = pentominoIDs, coords = boardCoords, orientations = orientations)
    pent2 = [pentominoIDs, boardCoords, orientations]
    pent2c = [pent2[0][:], pent2[1][:], pent2[2][:]]
    pent2[0] = sorted_list
    for j in pent2c[0]:
        new_ind = pent2[0].index(j)
        old_ind = pent2c[0].index(j)
        pent2[1][new_ind] = pent2c[1][old_ind]
        pent2[2][new_ind] = pent2c[2][old_ind]
    for i in range(len(boardCoords)):
        pent2[1][i][1] = 20-pent2[1][i][1]
        
    returnDict = dict()
    returnDict['area'] = np.sum(area)
    
    fencedTilesValue = []
    if fenced_areas != []:
        for i in range(len(fenced_areas)):
            for j in range(len(fenced_areas[i])):
                fencedTilesValue.append([fenced_areas[i][j][1], 19-fenced_areas[i][j][0]])
       
    returnDict['fencedTiles'] = fencedTilesValue

    returnDict['id'] = sorted_list
    return returnDict
    #return pent2, area, fenced_areas

def GetPentominos(imgPath, getArea = True):
    """
    Parameters
    ----------
    imgPath : image
        The image to process for pentominos. If the aruco corners are not
        present, will return something useless.
    getArea : Bool, optional
        Whether to return the area. The default is True.

    Returns
    -------
    pent2, a list of ids, coordinates, and orientations or both that and the
    fenced area of the pentominos
    
    """
    vs = VideoStream(imgPath)
    pent = vs.get_pentomino_placement()
    if type(pent) == str or pent is None or pent == [[],[],[],[],[]]:
        return 'No result! Check if the corners are in the frame and the pentominos are placed within the grid!'
    if pent is not None:
        pent2 = [pent[0], pent[4], pent[2]]
        if getArea == False:
            return pent2
        else:
            area, sorted_list, fenced_areas = vs.get_areas(pent)
            for id in pent2[0]:
                counter = 0
                for id2 in pent2[0]:
                    if id2 == id:
                        counter += 1
                        if counter > 1:
                            return 'Duplicate pentominos! Only use one of each shape!'
            if area == [] or area is None:
                return 'No fenced areas! Check the pentomino placements!'
            else:
                pent2c = [pent2[0][:], pent2[1][:], pent2[2][:]]
                pent2[0] = sorted_list
                for j in pent2c[0]:
                    new_ind = pent2[0].index(j)
                    old_ind = pent2c[0].index(j)
                    pent2[1][new_ind] = pent2c[1][old_ind]
                    pent2[2][new_ind] = pent2c[2][old_ind]
                    
                returnDict = dict()
                returnDict['area'] = int(np.sum(area))
                
                fencedTilesValue = []
                if fenced_areas != []:
                    for i in range(len(fenced_areas)):
                        for j in range(len(fenced_areas[i])):
                            fencedTilesValue.append([tile for tile in fenced_areas[i][j]])
                returnDict['fencedTiles'] = fencedTilesValue
                
                returnDict['id'] = sorted_list
                returnDict['coords'] = pent2[1]
                
                flips = []
                for i in pent2[2]:
                    if i > 3:
                        flips.append(1)
                    else:
                        flips.append(0)
                returnDict['flips'] = flips
                
                pent2[2] = [np.mod(4-i,4) for i in pent2[2]]
                returnDict['rotations'] = pent2[2]
                
                boardList = [[None for i in range(20)] for j in range(20)]
                for i in range(20):
                    for j in range(20):
                        if vs.board.board[i,j] != 0:
                            boardList[i][j] = True
                returnDict['boardPentList'] = boardList
                return returnDict
                #return pent2, area, fenced_areas
    else:
        return None

def GetUpdatedBoard(imgPath):
    vs = VideoStream(imgPath)
    return vs.get_updated_board()

def GetArea(ids = None, coords = None, orientations = None, pent = None, pent2 = None, imgPath = 'fuckthapolice'):
    """
    Parameters
    ----------
    ids : list<int>, optional
        List of pentomino ids for calculating fenced area.
    coords : list<[int, int]>, optional
        List of pentomino board coordinates for calculating fenced area.
    orientations : list<int>, optional
        List of pentomino orientations for calculating fenced area. 0-3 are
        number of 90 degree rotations to apply, 4-7 are the number of 90 degree
        rotations but with a flip.
    pent: list<list>, optional
        Use this if you have pent from get_pentomino_placements
    pent2: list<list>, optional
        Use this if you have pent2 from something that returns a pent2
    imgPath : image, optional
        You can specify this if just want area but do not care about pentomino
        placement.

    Returns
    -------
    int. The area. 
    """
    vs = VideoStream(imgPath)
    if pent != None:
        return vs.get_areas(pent = pent)
    elif imgPath != 'fuckthapolice':
        pent = vs.get_pentomino_placement()
        return vs.get_areas()
    elif pent2 != None:
        ids = pent2[0]
        coords = pent2[1]
        orientations = pent2[2]
        return vs.get_areas(ids = ids, board_coords = coords, orientations = orientations)
    else:
        return vs.get_areas(ids = ids, board_coords = coords, orientations = orientations)
    

class VideoStream:

    def __init__(self, image, width=1920, height=1080):

        #self.imgPath = image
        #image = cv2.imread(self.imgPath)
        
        image = np.asarray(image)
        self.source = image
        self.image = image
        self.frame = image
        self.stream = image  #Manu: This should change to a np.array (cv2)
        self.width = width
        self.height = height
        self.grid = BOARD_GRID
        # self.read_lock = Lock()
        #to get the current working directory
        # directory = os.getcwd()

        # print(directory)
        #df_raw = pd.read_csv('FenceChallenge/data/solutions-126.csv', header=None)
        #self.df = df_raw.iloc[:,1:]
        self.board = BOARD()
        #self.board = np.zeros((self.grid, self.grid))
        self.detector = PentominoDetector()

    #def ResetBoard(self):
        #self.board = np.zeros((self.grid, self.grid))

    def get_pentomino_placement(self, returnPent = True, returnCoordsAndOrds = True):
        """
        

        Parameters
        ----------
        returnPent : Bool, optional
            Whether to return the pent list of lists. This contains
            the pentomino placement information in the manner
            accepted by the pent input in get_areas. The default is True.
        returnCoordsAndOrds : Bool, optional
            Whether to return the pent2 list of lists, a stripped down
            version of pent. This is just ids, board coordinates, and 
            orientations. The default is True.
            If both above are false, returns a full list of board coordinates 
            occupied by pentominos

        Returns
        -------
        pent, pent2, or full list of coordinated occupied by pentominos

        """
        
        image = self.detector.transform_image(self.frame.copy())
    
        if image is None:
                # if not pygame.mixer.music.get_busy():
                #         pygame.mixer.init()
                #         pygame.mixer.music.load("corners.mp3")
                #         pygame.mixer.music.play()
            return 'No corners!'
        transformed_image = image.copy()
        pent = self.detector.find_pentominos(image)
        [ids, coords, orientations] = pent
        
        if pent == None:
            return 'No Pentominos found!'
        
        tempIds = [id -1 for id in ids]
        shapes = [PENTOMINOS_SHAPE[id] for id in tempIds]
    
        pent = [ids, shapes, orientations, coords]
        
        scale_width = 22 / image.shape[1]
        scale_height = 22 / image.shape[0]
        
        coord_list = []
        
        if len(ids) > 0:
            for coord in coords:
                x = int(coord[0]*scale_width)
                y = int(coord[1]*scale_height)
                coord_list.append([x,y])

        pent.append(coord_list)
        self.pent = pent
        
        if returnPent == True:
            return pent
        
        elif returnCoordsAndOrds == True:
            return [pent[0], pent[4], pent[2]]
        
        else:
            board_coords = pent[4]
            if len(ids) > 0:
                #self.ResetBoard()
                self.board.reset_board()
                for idd, orientation, board_coord in zip(ids, orientations, board_coords):

                    flip = False

                    if orientation >= 4:
                        orientation -= 4
                        flip = True

                    self.board.place_pentomino(idd-1, (board_coord[0],board_coord[1]), orientation, flip)
        
            board = self.board.board.copy()
            outCoordList = []
            for i in range(1,13):
                arucoCoord = np.argwhere(board == -i)
                coordList = np.argwhere(board == i)
                if len(arucoCoord)>0:
                    apdCoordList = [tuple([arucoCoord[0][0], arucoCoord[0][1]])]
                    for coord in coordList:
                        apdCoordList.append(tuple(coord))
                    outCoordList.append(apdCoordList)
            return outCoordList
        
        
    
    def get_areas(self, pent = None, ids = None, board_coords = None, orientations = None):
        if (pent == None) and (hasattr(self,'pent')):
            pent = self.pent
        if ids == None:
            ids = pent[0]
        if board_coords == None:
            board_coords = pent[4]
        if orientations == None:
            orientations = pent[2]
        if len(ids) > 0:
            #self.ResetBoard()
            self.board.reset_board()
            #coord_list = board_coords    
            for idd, orientation, board_coord in zip(ids, orientations, board_coords):
                flip = False

                if orientation >= 4:
                    orientation -= 4
                    flip = True

                self.board.place_pentomino(idd-1, (board_coord[0],board_coord[1]), orientation, flip)
                
            #print(self.board.board)
        
            #self.board.show_board()

            temp_board = self.board.board.copy()
            temp_board = np.where(temp_board!=0, 0, 255).astype(np.uint8)

            connected = cv2.connectedComponentsWithStats(temp_board,
                                                4,
                                                cv2.CV_32S)

            (totalLabels, label_ids, values, centroid) = connected
            unique, counts = np.unique(label_ids, return_counts=True)

            #for dangle in values:
                #print(dangle[-1])

            edge_areas = set()
            edge_areas.add(0)
            for line in label_ids:
                first = line[0]
                last = line[-1]
                if first >= 1:
                    edge_areas.add(first)
                if last >= 1:
                    edge_areas.add(last)

            for column in np.rot90(label_ids, 1):
                first = column[0]
                last = column[-1]
                if first >= 1:
                    edge_areas.add(first)
                if last >= 1:
                    edge_areas.add(last)

            sum_area = list()
            
            fenced_areas = list()
            
            count_area = 1

            #self.board.cv2_gui[85:550,580:980] = (0, 0, 0)

            for count, each in enumerate(centroid):
                if count not in edge_areas:
                    area = values[count][-1] #Manu: here we should allow for more holes to be considered, it is only taking the biggest component
                    
                    FA = np.argwhere(label_ids == count)
                    fenced_areas.append([list(i) for i in FA])
                    
                    sum_area.append(area)
                    #cv2.putText(self.board.cv2_gui, f'{count_area}', (round(each[0]*self.board.SIZE/self.board.GRID+55),round(each[1]*self.board.SIZE/self.board.GRID+70)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
                    #cv2.putText(self.board.cv2_gui, f'Area ({count_area}): {area}', (600, 125+count_area*50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                    count_area += 1
            
            x_offset = centroid[0][0]
            y_offset = centroid[0][1]
            
            coord_list = []
            
            for i in range(len(board_coords)):
                coord_list.append([board_coords[i][0], board_coords[i][1], ids[i]])
            
            sorted_list = sorted(coord_list, key=lambda x:np.arctan2(x[0]-y_offset,x[1]-x_offset))
            if len(sorted_list)>1:
                while sorted_list[0][2] != min(ids):
                    sorted_list = sorted_list[-1:] + sorted_list[:-1]
        
                if sorted_list[1][2] < sorted_list[-1][2]:
                    temp_pos = sorted_list[1:]
                    temp_pos.reverse()
                    sorted_list = sorted_list[:1] + temp_pos
    
            s = [x[2] for x in sorted_list]
            
            
            
            return sum_area, s, fenced_areas
    
    'This function was added by Miguel, it is the one returning the -pent- list with the info of the config'
    'np.array --> list[str, np.array, int'
    def get_pentominos(self):
        image = self.detector.transform_image(self.frame.copy())

        if image is None:
            return None
        transformed_image = image.copy()
        pent = self.detector.find_pentominos(image)
        [ids, coords, orientations] = pent

        #exchanges ids for characters
        #ids = [[list(pentominos.pentomino_names)[id], pentominos.PENTOMINOS_SHAPE[id]] for id in ids]

        #print(ids)


        tempIds = [id -1 for id in ids]
        shapes = [PENTOMINOS_SHAPE[id] for id in tempIds]

        

        #pent = [ids, shapes, coords, orientations]
        pent = [ids, shapes, orientations, coords]    
        
        #each orientation is 
        #This is what pent should look like when we add some more features:
        #pent = [ids, coords, orientations, total area, number of holes, tesselationtype (pentomino, polyamond,...), number of tiles]
        #There are more features that should be imported from get_status, such as the number of components and its areas
        
        if len(ids) > 0:
            #self.ResetBoard()
            self.board.reset_board()
            coords_list = list()
            for idd, coord, orientation in zip(ids, coords, orientations):

                scale_width = 22 / image.shape[1]
                scale_height = 22 / image.shape[0]

                x = int(coord[0]*scale_width)
                y = int(coord[1]*scale_height)

                flip = False

                if orientation >= 4:
                    orientation -= 4
                    flip = True

                self.board.place_pentomino(idd-1, (x,y), orientation, flip)

                coords_list.append([y, x, idd])
                
            #print(self.board.board)
            
            coordsListSansIds = [[a,b] for [a,b,c] in coords_list]
            pent.append(coordsListSansIds)
            #self.board.show_board()

            temp_board = self.board.board.copy()
            temp_board = np.where(temp_board!=0, 0, 255).astype(np.uint8)

            connected = cv2.connectedComponentsWithStats(temp_board,
                                                4,
                                                cv2.CV_32S)

            (totalLabels, label_ids, values, centroid) = connected
            unique, counts = np.unique(label_ids, return_counts=True)

            #for dangle in values:
                #print(dangle[-1])


            #this section gets rid of areas which use the edges of the board
            #as walls
            edge_areas = set()
            edge_areas.add(0)
            for line in label_ids:
                first = line[0]
                last = line[-1]
                if first >= 1:
                    edge_areas.add(first)
                if last >= 1:
                    edge_areas.add(last)

            for column in np.rot90(label_ids, 1):
                first = column[0]
                last = column[-1]
                if first >= 1:
                    edge_areas.add(first)
                if last >= 1:
                    edge_areas.add(last)

            sum_area = list()
            count_area = 1

            #self.board.cv2_gui[85:550,580:980] = (0, 0, 0)

            for count, each in enumerate(centroid):
                if count not in edge_areas:
                    area = values[count][-1] #Manu: here we should allow for more holes to be considered, it is only taking the biggest component
                    sum_area.append(area)
                    #cv2.putText(self.board.cv2_gui, f'{count_area}', (round(each[0]*self.board.SIZE/self.board.GRID+55),round(each[1]*self.board.SIZE/self.board.GRID+70)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
                    #cv2.putText(self.board.cv2_gui, f'Area ({count_area}): {area}', (600, 125+count_area*50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                    count_area += 1
            
            
            pent.append(sum_area)
            #self.board.write_fenced_area(sum_area)
            #cv2.imwrite('test.png', self.board.cv2_gui)            
        
        return pent
    
class BOARD:
    def __init__(self):

        self.colors = [(150,255,255),
                  (255,150,150),
                  (150,150,255),
                  (200,0,0),
                  (150,255,150),
                  (255,255,150),
                  (255,150,255),
                  (200,200,0),
                  (0,200,0),
                  (0,0,200),
                  (200,0,200),
                  (0,200,200)]

        self.border = 1
        
        self.cv2_gui = np.full(shape=(600,1000,3), fill_value=0, dtype=np.uint8)

        self.SIZE = BOARD_SIZE
        self.GRID = BOARD_GRID

        self.board = np.zeros((self.GRID,self.GRID), dtype=int)

        self.cv2_board = np.full(shape=(self.SIZE,self.SIZE,3), fill_value=0, dtype=np.uint8)


        self.draw_grid()
        #self.show_board()


    def pick_and_place(self, event, x, y, flags, param):

        if event == cv2.EVENT_LBUTTONDOWN:

            if 50 <= x < 550 and 50 <= y < 550:
                x = int((x-50) / (self.SIZE/self.GRID))
                y = int((y-50) / (self.SIZE/self.GRID))
                shape_id = self.board[y,x]
                if shape_id < 0:
                    shape_id *= -1
                if shape_id > 0:
                    self.last_item(shape_id)

    def last_item(self, shape_id: int):
        self.item = np.full(shape=(150,150,3), fill_value=0, dtype=np.uint8)
        size = int(self.SIZE / self.GRID)
        pentomino = np.array(PENTOMINOS_SHAPE[shape_id-1])
        pentomino[pentomino == 'x'] = shape_id + 1
        pentomino = pentomino.astype(int)
        y_start = int((self.item.shape[0]-pentomino.shape[0]*size) / 2)
        x_start = int((self.item.shape[1]-pentomino.shape[1]*size) / 2)

        for row in range(pentomino.shape[0]):
            for col in range(pentomino.shape[1]):
                if pentomino[row,col] > 0:

                    x = x_start + col*size
                    y = y_start + row*size

                    self.item[y:y+size:,x:x+size] = 255
                    self.item[y+self.border:y+size-self.border,x+self.border:x+size-self.border] = self.colors[shape_id-1]


    def show_board(self):

        self.cv2_gui[50:550,50:550] = self.cv2_board

        self.fontFace = cv2.FONT_HERSHEY_SIMPLEX
        self.fontScale = 1
        self.fontColor = (255, 255, 255)
        self.fontThickness = 2


    def write_fenced_area(self, area: list):
        cv2.putText(self.cv2_gui, f'Fenced areas: {sum(area)}', (600, 125), self.fontFace, self.fontScale, self.fontColor, thickness=self.fontThickness)

    def write_max_area(self, area: int):
        self.cv2_gui[25:85,580:780] = (0, 0, 0)
        if area < 126:
            area = "up to 125"
        cv2.putText(self.cv2_gui, f'Max area: {area}', (600, 75), self.fontFace, self.fontScale, self.fontColor, thickness=self.fontThickness)

    def place_pentomino(self, shape_id: int, position: tuple, rotate: int=0, flip: bool=False):


        pentomino = np.array(PENTOMINOS_SHAPE[shape_id])


        if flip:
            pentomino = np.flip(pentomino, 1)

        for angle in range(rotate):
            pentomino = np.rot90(pentomino)

        offset_y, offset_x = np.where(pentomino == 'x')

        position_lt_x = position[0] - offset_x[0] - 1
        position_lt_y = position[1] - offset_y[0] - 1

        # print(shape_id, offset_y, offset_x)
        if (position_lt_x+pentomino.shape[1]) <= self.GRID and (position_lt_y+pentomino.shape[0]) <= self.GRID:

            board_cutout = self.board[position_lt_y:position_lt_y+pentomino.shape[0],position_lt_x:position_lt_x+pentomino.shape[1]].copy()
            board_cutout = np.where(board_cutout<0,-board_cutout,board_cutout)
            board_cutout = np.where(board_cutout>0,-1,-2)

            pentomino_replaced = pentomino.copy()
            pentomino_replaced[pentomino == 'x'] = shape_id + 1
            pentomino_replaced = pentomino_replaced.astype(int)
            """
            THIS IS A BUG FIX MAKE SURE IT WORKS
            ||
            V
            """
            if 0 in board_cutout.shape or 0 in np.where(pentomino_replaced>0,-1, shape_id+1).shape:
                return None

            if True in np.where(board_cutout==np.where(pentomino_replaced>0,-1, shape_id+1), True, False):
                print('Rule check! - Blocked')
                return None
            else:
                board_cutout = self.board[position_lt_y:position_lt_y+pentomino.shape[0],position_lt_x:position_lt_x+pentomino.shape[1]] | pentomino_replaced

                board_cutout[pentomino == 'x'] = -(shape_id + 1)

                self.board[position_lt_y:position_lt_y+pentomino.shape[0],position_lt_x:position_lt_x+pentomino.shape[1]] = board_cutout

                for row in range(pentomino.shape[0]):
                    for col in range(pentomino.shape[1]):

                        size = int(self.SIZE / self.GRID)
                        x = (row + position_lt_y) * size
                        y = (col + position_lt_x) * size



                        if abs(self.board[row + position_lt_y,col + position_lt_x]) == shape_id + 1:

                            self.cv2_board[x:x+size:,y:y+size] = 255
                            self.cv2_board[x+self.border:x+size-self.border,y+self.border:y+size-self.border] = self.colors[shape_id]
                        # elif self.board[row + position_lt_y,col + position_lt_x] == -(shape_id + 1):
                        #
                        #     self.cv2_board[x:x+size:,y:y+size] = 255
                        #     self.cv2_board[x+self.border:x+size-self.border,y+self.border:y+size-self.border] = 0
                        #     self.cv2_board[x+int(3/8*size):x+int(5/8*size),y+int(3/8*size):y+int(5/8*size)] = 255
        else:
            print('Rule Check! - Out of Area')
            return None

        # self.last_item(shape_id+1)

    def reset_board(self):
        self.board = np.zeros((self.GRID,self.GRID), dtype=int)
        self.draw_grid()

    def draw_grid(self):
        self.cv2_board[:,:] = (80,80,0)
        for row in range(self.GRID):
            for col in range(self.GRID):
                size = int(self.SIZE / self.GRID)
                x = row * size
                y = col * size
                self.cv2_board[x+self.border:x+size-self.border,y+self.border:y+size-self.border] = 0

if __name__ == "__main__":

    print(GetPentominos('data/test.jpg'))
    
